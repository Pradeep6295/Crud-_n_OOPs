<?php
    include 'model.php';
    $obj =new Model();
    //print_r($obj);
    if(isset($_POST['submit']) ){
       
        $obj->DataInsert($_POST);
    }
    if(isset($_POST['update']) ){
        $obj->updateData($_POST);
    }
    if( isset($_GET['did']) ){
        $did=$_GET['did'];
       $obj->deleteData($did);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <title>OOPs</title>
</head>
<body>
   <div class="container mt-5">
        <div class="card">
            <?php
                //insert data msg
                if(isset($_GET['msg']) AND $_GET['msg']=='ins'){
                    echo '<div class="alert alert-success" role="alert">
                            Datat Inserted!
                        </div>';
                }
            ?>
            <div class="card-body m-3">
                <?php
                    if( isset($_GET['eid']) ){
                        $eid =$_GET['eid'];
                        $myrec =$obj->displayRecordById($eid);
                        print_r($myrec);
                   
                ?> 
                <!-- Update Form -->
                <form action="" method="post">
                    <div class="input-group mb-3 p-3">
                        <span class="input-group-text" id="basic-addon1">Name</span>
                        <input type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1"name="name" value="<?php echo $myrec['name']; ?>">
                    </div>
                    <div class="input-group mb-3 p-3">
                        <span class="input-group-text" id="basic-addon1">Mobile</span>
                        <input type="text" class="form-control" placeholder="Mobile" aria-label="Username" aria-describedby="basic-addon1" name="mobile"value="<?php echo $myrec['Mobile']; ?>">
                    </div>
                    <div class="input-group mb-3 p-3">
                        <span class="input-group-text" id="basic-addon1">Age</span>
                        <input type="text" class="form-control" placeholder="Age" aria-label="Username" aria-describedby="basic-addon1" name="age"
                        value="<?php echo $myrec['age']; ?>">
                    </div>
                    <div class="input-group mb-3 p-3">
                        <input type="hidden" name="hid" value="<?php echo $myrec['id']; ?>">
                        <input type="submit" name="update" class ="btn btn-warning" value="Update">
                    </div>
                </form>
                    <?php
                         }else{
                    ?>
                    <form action="" method="post">
                        <div class="input-group mb-3 p-3">
                            <span class="input-group-text" id="basic-addon1">Name</span>
                            <input type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1" name="name">
                        </div>
                        <div class="input-group mb-3 p-3">
                            <span class="input-group-text" id="basic-addon1">Mobile</span>
                            <input type="text" class="form-control" placeholder="Mobile" aria-label="Username" aria-describedby="basic-addon1" name="mobile">
                        </div>
                        <div class="input-group mb-3 p-3">
                            <span class="input-group-text" id="basic-addon1">Age</span>
                            <input type="text" class="form-control" placeholder="Age" aria-label="Username" aria-describedby="basic-addon1" name="age">
                        </div>
                        <div class="input-group mb-3 p-3">
                            <input type="submit" name="submit" value="Submit">
                        </div>
                    </form>
                    <?php
                         }
                    ?>
            </div>
        </div>
        <div class="card mt-3">
            <div class="card-body">
            <?php
                //Update msg
                if(isset($_GET['msg']) AND $_GET['msg']=='upd'){
                    echo '<div class="alert alert-success" role="alert">
                            Datat Updated!
                        </div>';
                }
                //Delete Msg
                if(isset($_GET['msg']) AND $_GET['msg']=='deleted'){
                    echo '<div class="alert alert-success" role="alert">
                            Data is Delete!
                        </div>';
                }
            ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Name</th>
                            <th scope="col">Mobile</th>
                            <th scope="col">Age</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $data = $obj->displayRecord();
                            foreach($data as $value){
                        ?>
                        <tr>
                            <th scope="row"><?php echo $value['id']; ?></th>
                            <td><?php echo $value['name']; ?></td>
                            <td><?php echo $value['Mobile']; ?></td>
                            <td><?php echo $value['age']; ?></td>
                            <td> <a href="index.php?eid=<?php echo $value['id']; ?>" class="btn btn-warning"> Edid </a> <a href="index.php?did=<?php echo $value['id']; ?>" class="btn btn-danger" name="delete"> Delete </a>  </td>
                            
                        </tr>
                        <?php }?>
                    </tbody>
                </table>
            </div>
        </div>
        

<!-- <nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="#">Home</a></li>
    <li class="breadcrumb-item"><a href="#">Library</a></li>
    <li class="breadcrumb-item active" aria-current="page">Data</li>
  </ol>
</nav> -->
   </div> 
</body>
</html>