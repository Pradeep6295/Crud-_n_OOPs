<?php
    class Model{

        private $db_host ='localhost';
        private $db_user ='root';
        private $db_password ='';
        private $db_name ='test';
        private $conn;

        function __construct(){
            $this->conn = new mysqli($this->db_host, $this->db_user, $this->db_password, $this->db_name);

            if($this->conn->connect_error){
                echo "Connection failed";
            }
            else{
                return $this->conn;
            }
        }//Construct End

        //Add Record function
        public function DataInsert($post){
            $name =$post['name'];
            $mobile =$post['mobile'];
            $age =$post['age'];
            $sql ="insert into students(`name`,`Mobile`,`age`) value('$name','$mobile','$age') ";
            $result =$this->conn->query($sql);
            if($result){
                header("location:index.php?msg=ins");
            }else{
                echo "ERROR" .$sql. "<br>" .$this->conn->error;
            }
        }//Add Record function 

        //displayRecord function start
        public function displayRecord(){
            $sql ="select * from students";
            $result = $this->conn->query($sql);
            if($result){
                while($row = $result->fetch_assoc() ){
                    $data[]=$row;
                }
                return $data;
            }
        }//displayRecord function end

        //displayRecordById function start
        public function displayRecordById($eid){
            $sql ="select * from students where id=$eid";
            $result =$this->conn->query($sql);
            if(!empty($result) && $result->num_rows > 0){
                $row = $result->fetch_assoc();
                return $row;
            }else{
                echo "No Data Found";
            }
        }//displayRecordById function end

        //Update function start
        public function updateData($post){
            $name =$post['name'];
            $mobile =$post['mobile'];
            $age =$post['age'];
            $eid =$post['hid'];
            $sql ="update students set name ='$name',Mobile='$mobile',age='$age' where id='$eid' ";
            $result =$this->conn->query($sql);
            if($result){
                header("location:index.php?msg=upd");
            }else{
                echo "ERROR" .$sql. "<br>" .$this->conn->error;
            }
        }//Update function start end

        //delete function start
        public function deleteData($did){
            $sql ="delete from students where id='$did' ";
            $result =$this->conn->query($sql);
            if($result){
                header("location:index.php?msg=deleted");
            }else{
                echo "ERROR" .$sql. "<br>" .$this->conn->error;
            } 
        }//delete function end
    }//Class end

?>